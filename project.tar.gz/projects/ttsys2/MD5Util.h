#ifndef _MD5_UTIL_INCLUDE_H_
#define _MD5_UTIL_INCLUDE_H_

#include <openssl/md5.h>

#ifdef __cplusplus
extern "C" {
#endif


void MDString1(char *string,char *mdstring);


#ifdef __cplusplus
}
#endif

#endif
