#ifndef _NOTE_ERROR_H_
#define _NOTE_ERROR_H_

#define NOTE_ERROR          -6300
#define NOTE_NOMEMORY       -6301
#define NOTE_FILEERROR      -6302
#define NOTE_DATADUP        -6303
#define NOTE_DATALOST       -6304
#define NOTE_NOTFOUND       -6305
#define NOTE_FORMATERROR    -6306
#define NOTE_DATASIZEERROR  -6307
#define NOTE_ENDOFDATA      -6308

#endif
