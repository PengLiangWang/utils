#include "dbactiontype.h"

extern char *keywordList[];

extern int		lineCnt;
extern int		_lineOver;
extern int		_lineBegin;
extern int		_getField;
extern char		*tableName;
extern char		*tName;
extern FieldList	fList;
extern ArgList		aList;
extern int		aType;
extern char		*sName;
extern FILE		*i_file;
extern FILE		*c_file;
extern FILE		*ec_file;
extern FILE		*sql_file;
extern char		includeFileName[128];
extern char		SqlFileName[128];
extern char		cFileName[128];
extern char		actFileName[128];
extern char		systemDate[128];
extern char		hasDAC;
extern int		_indexFileNo;
extern int		_scale;
extern int		_notNull;

